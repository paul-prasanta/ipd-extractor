/*
 * Copyright (C) 2011 Prasanta Paul, http://prasanta-paul.blogspot.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.pras;

import java.util.ArrayList;

import com.pras.IPDParser.Callback;
import com.pras.info.Contact;
import com.pras.info.SMS;

public class Main implements Callback {

	long startTime = 0;
	IPDParser parser;
	
	public void parseIPD(String fileName)
	{		
		try{
			startTime = System.currentTimeMillis();
			parser = new IPDParser(fileName, this);
			parser.parse();
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	// Parsing complete Callback
	public void parseComplete(ArrayList<Contact> contacts, ArrayList<SMS> sms) 
	{
		int countOfContact = 0;
		int countOfSMS = 0;
		if(contacts != null)
			countOfContact = contacts.size();
		if(sms != null)
			countOfSMS = sms.size();
		
		System.out.println("Number of Contacts: "+ countOfContact);
		System.out.println("Number of SMS: "+ countOfSMS);
		
		// Generate CSV
		CSVGenerator csv = new CSVGenerator();
		csv.generateCSV(contacts, sms);
		
		long reqTime = System.currentTimeMillis() - startTime;
		// Parsing + CSV Generation time....
		System.out.println("[Time Req]: "+ reqTime +" milliseconds!!");
		System.out.println("[Prasanta]: Post your feedback to http://prasanta-paul.blogspot.com/");
	}
	
	public static void main(String[] args){
		if(args.length == 0)
			throw new InternalError("Missing IPD file name!!\n\n Usage: java -cp ipd_parser.jar com.pras.Main <IPD File Name>");
		
		Main m = new Main();
		m.parseIPD(args[0]);
	}
}
