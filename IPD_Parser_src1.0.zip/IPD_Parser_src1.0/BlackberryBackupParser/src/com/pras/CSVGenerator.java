/*
 * Copyright (C) 2011 Prasanta Paul, http://prasanta-paul.blogspot.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.pras;

import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import com.pras.info.Address;
import com.pras.info.Contact;
import com.pras.info.ContactFields;
import com.pras.info.SMS;

public class CSVGenerator {
	
	String path = System.getProperty("user.dir") + System.getProperty("file.separator");
	
	// Contact columns
	String[] contact_cols = {"FName", "MName", "LName", "Title", "Company", "Designation",
					 "Email", "Phone Number", "Address", "Birthday", "Anniversary",
					 "Web Page", "Note"};
	// SMS columns
	String[] sms_cols = {"Number", "Sent Date", "Received Date", "Text"}; 
	
	/**
	 * Generate 2 CSV files
	 * - contacts_<timestamp>.csv
	 * - sms_<timestamp>.csv
	 * 
	 * @param contacts
	 * @param sms
	 */
	public void generateCSV(ArrayList<Contact> contacts, ArrayList<SMS> sms)
	{
		System.out.println("Generating CSV....");
		if(contacts == null || contacts.size() == 0)
			System.out.println("No Contacts!!");
		else
			generateContactCSV(contacts);
		
		if(sms == null || sms.size() == 0)
			System.out.println("No SMS!!");
		else
			generateSMSCSV(sms);
	}
	
	private void generateSMSCSV(ArrayList<SMS> sms)
	{
		System.out.println("Generating SMS CSV....");
		StringBuffer row = new StringBuffer("");

		// Add columns
		for (int i = 0; i < sms_cols.length; i++) {
			row.append(sms_cols[i]);
			if (i < sms_cols.length - 1)
				row.append(", ");
		}
		row.append("\n");
		
		// SMS data
		for(int i=0; i<sms.size(); i++){
			SMS msg = sms.get(i);
			row.append(escapeQuote(msg.getNumber())+" ,");
			row.append(escapeQuote(new Date(msg.getSentDate()).toString())+" ,");
			row.append(escapeQuote(new Date(msg.getReceivedDate()).toString())+" ,");
			row.append(escapeQuote(""+ msg.getText()));
			
			if(i < sms.size() - 1)
				row.append("\n");
		}
		
		// Generate File
		try{
			String fileName = "sms_"+ new Date().getTime() +".csv";
			generateFile(fileName, row.toString());
		}catch(Exception ex){
			System.out.println("Error in creating SMS CSV file: "+ ex.toString());
			ex.printStackTrace();
			return;
		}
		System.out.println("SMS CSV...[DONE]");
	}
	
	/**
	 * Generate CSV file for Contact
	 * @param contacts
	 */
	private void generateContactCSV(ArrayList<Contact> contacts)
	{
		System.out.println("Generating Contact CSV...");
		StringBuffer row = new StringBuffer("");
		
		// Add columns
		for(int i=0; i<contact_cols.length; i++){
			row.append(contact_cols[i]);
			if(i < contact_cols.length - 1)
				row.append(", ");
		}
		row.append("\n");
		
		// Add Contact data
		for(int i=0; i<contacts.size(); i++){
			row.append(addContact(contacts.get(i)));
			if(i < contacts.size() - 1)
				row.append("\n");
		}
		
		// Generate File
		try{
			String fileName = "contact_"+ new Date().getTime() +".csv";
			generateFile(fileName, row.toString());
		}catch(Exception ex){
			System.out.println("Error in creating Contact CSV file: "+ ex.toString());
			ex.printStackTrace();
			return;
		}
		System.out.println("Contact CSV...[DONE]");
	}
	
	/**
	 * Generate CSV file
	 * 
	 * @param fileName
	 * @param data
	 * @throws Exception
	 */
	private void generateFile(String fileName, String data) throws Exception 
	{
		String file = path + fileName;
		FileOutputStream out = new FileOutputStream(file);
		PrintWriter writer = new PrintWriter(out);
		writer.print(data);
		writer.flush();
		writer.close();
		out.close();
	}
	
	/**
	 * Add Contact details in CSV format
	 * @param contact
	 */
	private String addContact(Contact contact)
	{
		StringBuffer row = new StringBuffer();
		
		// First Name
		row.append(""+ escapeQuote(contact.getFirstName())+" ,");
		
		// Middle Name
		row.append(""+ escapeQuote(contact.getMiddleName())+" ,");

		// Last Name
		row.append(""+ escapeQuote(contact.getLastName())+" ,");

		// Title
		row.append(""+ escapeQuote(contact.getTitle())+" ,");

		// Company
		row.append(""+ escapeQuote(contact.getCompany())+" ,");

		// Designation
		row.append(""+ escapeQuote(contact.getDesignation())+" ,");

		// Emails
		if(contact.getEmails().size() > 0){
			ArrayList<String> emails = contact.getEmails();
			row.append("\" ");
			 for(int i=0; i<emails.size(); i++){
				 row.append(emails.get(i));
				 if(i < emails.size() - 1)
					 row.append(", ");
			 }
			 row.append("\", ");
		}
		else{
			row.append("\"\", ");
		}
		
		// Phone Numbers
		if(contact.getPhoneNumbers().size() > 0){
			HashMap<Byte, String> numbers = contact.getPhoneNumbers();
			row.append("\" ");
			Set<Byte> keys = numbers.keySet();
			Iterator<Byte> it = keys.iterator();
			while(it.hasNext()){
				byte code = it.next();
				if(code == ContactFields.HOME1_PHONE_FIELD)
					row.append("Home_Phone1: "+ numbers.get(code));
				else if(code == ContactFields.HOME2_PHONE_FIELD)
					row.append("Home_Phone2: "+ numbers.get(code));
				else if(code == ContactFields.MOBILE1_FIELD)
					row.append("Mobile_Phone1: "+ numbers.get(code));
				else if(code == ContactFields.MOBILE2_FIELD)
					row.append("Mobile_Phone2: "+ numbers.get(code));
				else if(code == ContactFields.WORK1_PHONE_FIELD)
					row.append("Work_Phone1: "+ numbers.get(code));
				else if(code == ContactFields.WORK2_PHONE_FIELD)
					row.append("Work_Phone2: "+ numbers.get(code));
				else if(code == ContactFields.FAX1_FIELD)
					row.append("FAX_Phone1: "+ numbers.get(code));
				else if(code == ContactFields.FAX2_FIELD)
					row.append("FAX_Phone2: "+ numbers.get(code));
				else if(code == ContactFields.PAGER_FIELD)
					row.append("Pager: "+ numbers.get(code));
				else if(code == ContactFields.PIN_FIELD)
					row.append("Pin: "+ numbers.get(code));
				else if(code == ContactFields.OTHER_FIELD)
					row.append("Other: "+ numbers.get(code));
				if(it.hasNext())
					row.append(" ");
			}
			row.append("\", ");
		}
		else{
			row.append("\"\", ");
		}
		
		// Address
		if(contact.getAddress().size() > 0) {
			
			// Beginning Quote
			row.append("\" ");
			/*
			 * Prefix Address type
			 * "Home_#45, Home_Sector71, Home_Noida, Home_UP, Home_201301, Home_India, Work_C28/29, Work_sector61, Work_Noida ...."
			 */
			HashMap<Integer, Address> ads = contact.getAddress(); 
			Set<Integer> keys = ads.keySet();
			Iterator<Integer> it = keys.iterator();
			
			String prefix = "Other_";
			int key = Contact.OTHER_ADDRESS;
			while(it.hasNext()){
				key = it.next();
				Address ad = ads.get(key);
				
				if(key == Contact.HOME_ADDRESS)
					prefix = "Home_";
				else if(key == Contact.WORK_ADDRESS)
					prefix = "Work_";
				
				
				// Address 1
				row.append(""+ escapeQuote(prefix + ad.getAddress())+" ");
				// Address 2
				row.append(""+ escapeQuote(prefix + ad.getAddress2())+" ");
				// City
				row.append(""+ escapeQuote(prefix + ad.getCity())+" ");
				// State
				row.append(""+ escapeQuote(prefix + ad.getState())+" ");
				// PIN
				row.append(""+ escapeQuote(prefix + ad.getPin())+" ");
				// Country
				row.append(""+ escapeQuote(prefix + ad.getCountry()));
				
				if(it.hasNext())
					row.append(" ");
			}
			// End Quote
			row.append("\", ");
		}
		else
			row.append("\"\", ");
		
		// Birthday
		row.append(""+ escapeQuote(contact.getBirthday())+" ,");
		
		// Anniversary
		row.append(""+ escapeQuote(contact.getAnniversary())+" ,");
		
		// WebPage
		row.append(""+ escapeQuote(contact.getWebPage())+" ,");
		
		// Note
		row.append(""+ escapeQuote(contact.getNote()));
		
		
		return row.toString();
	}
	
	/**
	 * As per CSV specification, for special characters additional quotes need to be surrounded 
	 * around the CSV filed value
	 * Ref: http://en.wikipedia.org/wiki/Comma-separated_values
	 * @return
	 */
	public static String escapeQuote(String data)
	{
		if(data == null || data.trim() == "")
			return "\"\"";
		
		StringBuffer buf = new StringBuffer(data);
		/*
		 * CSV fields that contain commas, double-quotes, or line-breaks must be quoted.
		 */
		boolean needCoverQuote = false;
		
		for(int i=0; i<buf.length(); i++){
			if(buf.charAt(i) == '"'){
				buf.insert(i, '"');
				// Skip these 2 quotes
				i = i + 1;
				needCoverQuote = true;
			}
			else if(buf.charAt(i) == ',' || buf.charAt(i) == '\n' || buf.charAt(i) == '\r')
				needCoverQuote = true;
		}
		
		if(needCoverQuote){
			// Beginning quote
			buf.insert(0, "\"");
			// End quote
			buf.insert(buf.length(), "\"");
		}
		
		return buf.toString();
	}
	
	public static void main(String[] args){
		System.out.println("Changed Str: "+ escapeQuote("A Kingh "+ (char)'\n' +" Tale!"));
		
		StringBuffer row = new StringBuffer("Hi, I'm good,");
		row.deleteCharAt(row.length() - 1);
		
		System.out.println("Row: "+ row.toString());
	}
}
