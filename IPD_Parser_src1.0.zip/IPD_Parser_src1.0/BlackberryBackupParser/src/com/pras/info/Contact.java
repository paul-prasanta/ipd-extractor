/*
 * Copyright (C) 2011 Prasanta Paul, http://prasanta-paul.blogspot.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.pras.info;

import java.util.ArrayList;
import java.util.HashMap;

public class Contact extends IPDRecord {
	
	/**
	 * IPD Field type which contains all information
	 * IPD Field Type- 10
	 */
	public static final int CONTACT_DATA_TYPE = 10;
	public static final int WORK_ADDRESS = 1;
	public static final int HOME_ADDRESS = 2;
	public static final int OTHER_ADDRESS = 3;
	
	String firstName;
	String middleName;
	String lastName;
	String title;
	String company;
	String designation;

	ArrayList<String> emails = new ArrayList<String>();
	HashMap<Byte, String> phoneNumbers = new HashMap<Byte, String>();
	HashMap<Integer, Address> address = new HashMap<Integer, Address>();
	
	/**
	 * TODO: convert String date to long
	 */
	String birthday;
	/**
	 * Convert String date to long
	 */
	String anniversary;
	String webPage;
	String note;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public ArrayList<String> getEmails() {
		return emails;
	}
	public void setEmails(ArrayList<String> emails) {
		this.emails = emails;
	}
	public void addEmail(String email){
		this.emails.add(email);
	}
	public HashMap<Byte, String> getPhoneNumbers() {
		return phoneNumbers;
	}
	public void addPhoneNumber(byte phoneType, String phoneNumber){
		this.phoneNumbers.put(phoneType, phoneNumber);
	}
	public void setPhoneNumbers(HashMap<Byte, String> phoneNumbers) {
		this.phoneNumbers = phoneNumbers;
	}
	public HashMap<Integer, Address> getAddress() {
		return address;
	}
	public void addAddress(int addressType, Address address){
		this.address.put(addressType, address);
	}
	public void setAddress(HashMap<Integer, Address> address) {
		this.address = address;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getAnniversary() {
		return anniversary;
	}
	public void setAnniversary(String anniversary) {
		this.anniversary = anniversary;
	}
	public String getWebPage() {
		return webPage;
	}
	public void setWebPage(String webPage) {
		this.webPage = webPage;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
}
