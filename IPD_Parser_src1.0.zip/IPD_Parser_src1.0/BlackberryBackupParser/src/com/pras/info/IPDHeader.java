/*
 * Copyright (C) 2011 Prasanta Paul, http://prasanta-paul.blogspot.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.pras.info;

public class IPDHeader {

	String rimSignature;
	int lineBreak;
	int dbVersion;
	int countOfDB;
	int dbSeperator;
	public String getRimSignature() {
		return rimSignature;
	}
	public void setRimSignature(String rimSignature) {
		this.rimSignature = rimSignature;
	}
	public int getLineBreak() {
		return lineBreak;
	}
	public void setLineBreak(int lineBreak) {
		this.lineBreak = lineBreak;
	}
	public int getDbVersion() {
		return dbVersion;
	}
	public void setDbVersion(int dbVersion) {
		this.dbVersion = dbVersion;
	}
	public int getCountOfDB() {
		return countOfDB;
	}
	public void setCountOfDB(int countOfDB) {
		this.countOfDB = countOfDB;
	}
	public int getDbSeperator() {
		return dbSeperator;
	}
	public void setDbSeperator(int dbSeperator) {
		this.dbSeperator = dbSeperator;
	}
}
