/*
 * Copyright (C) 2011 Prasanta Paul, http://prasanta-paul.blogspot.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.pras.info;

public class ContactFields {
	/* Contact Field IDs */
	public static final byte NAME_FIELD = 0x20;
	public static final byte TITLE_FIELD = 0x37;
	public static final byte COMPANY_NAME_FIELD = 0x21;
	public static final byte DESIGNATION_FIELD = 0x2A;
	public static final byte EMAIL_FIELD = 0x01;
	// Phone Number
	public static final byte WORK1_PHONE_FIELD = 0x06;
	public static final byte WORK2_PHONE_FIELD = 0x10;
	public static final byte HOME1_PHONE_FIELD = 0x07;
	public static final byte HOME2_PHONE_FIELD = 0x11;
	public static final byte MOBILE1_FIELD = 0x08;
	public static final byte MOBILE2_FIELD = 0x13;
	public static final byte PAGER_FIELD = 0x09;
	public static final byte FAX1_FIELD = 0x03;
	public static final byte FAX2_FIELD = 0x14;
	public static final byte OTHER_FIELD = 0x12;
	public static final byte PIN_FIELD = 0x0A;
	// Address
	// Address - Work
	public static final byte WORK_ADDRESS_FIELD = 0x23;
	public static final byte WORK_ADDRESS2_FIELD = 0x24;
	public static final byte WORK_CITY_FIELD = 0x26;
	public static final byte WORK_STATE_FIELD = 0x27;
	public static final byte WORK_PIN_FIELD = 0x28;
	public static final byte WORK_COUNTRY_FIELD = 0x29;
	// Address - Home
	public static final byte HOME_ADDRESS_FIELD = 0x3D;
	public static final byte HOME_ADDRESS2_FIELD = 0x3E;
	public static final byte HOME_CITY_FIELD = 0x45;
	public static final byte HOME_STATE_FIELD = 0x46;
	public static final byte HOME_PIN_FIELD = 0x47;
	public static final byte HOME_COUNTRY_FIELD = 0x48;
	
	public static final byte BIRTHDAY_FIELD = 0x52;
	public static final byte ANNIVERSARY_FIELD = 0x53;
	public static final byte WEBPAGE_FIELD = 0x36;
	public static final byte NOTE_FIELD = 0x40;
}
