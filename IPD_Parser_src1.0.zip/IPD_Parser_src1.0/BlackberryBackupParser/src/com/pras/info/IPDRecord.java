/*
 * Copyright (C) 2011 Prasanta Paul, http://prasanta-paul.blogspot.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.pras.info;

import java.util.ArrayList;

/**
 * Represents one roz of Dqtq
 * 
 * @author prasanta
 *
 */
public class IPDRecord {
	int dbID;
	int recordLength;
	int dbVersion;
	int recordHandle;
	int recordUID;
	ArrayList<IPDField> fields = new ArrayList<IPDField>();
	
	public int getDbID() {
		return dbID;
	}
	public void setDbID(int dbID) {
		this.dbID = dbID;
	}
	public int getRecordLength() {
		return recordLength;
	}
	public void setRecordLength(int recordLength) {
		this.recordLength = recordLength;
	}
	public int getDbVersion() {
		return dbVersion;
	}
	public void setDbVersion(int dbVersion) {
		this.dbVersion = dbVersion;
	}
	public int getRecordHandle() {
		return recordHandle;
	}
	public void setRecordHandle(int recordHandle) {
		this.recordHandle = recordHandle;
	}
	public int getRecordUID() {
		return recordUID;
	}
	public void setRecordUID(int recordUID) {
		this.recordUID = recordUID;
	}
	public ArrayList<IPDField> getFields() {
		return fields;
	}
	public void setFields(ArrayList<IPDField> fields) {
		this.fields = fields;
	}
	
	public void addField(IPDField field){
		this.fields.add(field);
	}
}
