/*
 * Copyright (C) 2011 Prasanta Paul, http://prasanta-paul.blogspot.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.pras;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import com.pras.info.Address;
import com.pras.info.Contact;
import com.pras.info.ContactFields;
import com.pras.info.IPDField;
import com.pras.info.IPDHeader;
import com.pras.info.IPDRecord;
import com.pras.info.IPD_DBName;
import com.pras.info.SMS;

/**
 * IPD File Parser.
 * To get output of parsing process, User program need to Linsten to
 * Callback
 * 
 * @author Prasanta Paul
 *
 */
public class IPDParser {

	/* Backup File */
	final String backup_file = "";
	String fs = System.getProperty("file.separator");
	String path = "";
	
	/* BBParser Listener */
	Callback listener;
	
	/* IPD Data Variables */
	final int HEADER_SIZE = 42;
	final String RIM_HEADER_SIG = "Inter@ctive Pager Backup/Restore File";
	IPDHeader ipd_header;
	ArrayList<IPD_DBName> dbNames = new ArrayList<IPD_DBName>();
	private ArrayList<SMS> smsRecords = new ArrayList<SMS>();
	private ArrayList<Contact> contactRecords = new ArrayList<Contact>();
	
	/* Content Flags */
	boolean isSMS = false;
	boolean isContact = false;
	
	public IPDParser(){
		// Use the pre-built backup file
		this.path += backup_file;
	}
	
	public IPDParser(String file, Callback callback){
		this.path = file;
		this.listener = callback;
	}
	
	/**
	 * Parse IPD file
	 * @throws Exception
	 */
	public void parse() throws Exception 
	{
		if(path == null || path == "" || !path.endsWith(".ipd"))
			throw new IOException("No backup file found!!");
		
		FileInputStream fin = new FileInputStream(this.path);
		
		System.out.println("Total Size: "+ fin.available());

		// Read IPD Header
		byte[] ipd_header_bytes = new byte[HEADER_SIZE];
		fin.read(ipd_header_bytes);
		IPDHeader ipd_header = processHeader(ipd_header_bytes);
		
		// Is it a valid IPD file ?
		if(!ipd_header.getRimSignature().equals(RIM_HEADER_SIG))
		{
			throw new InternalError("Incompatible backup file...");
		}
		
		// Read DBName
		System.out.println("Number of DB Name to parse: "+ ipd_header.getCountOfDB());
		
		for(int i=0; i<ipd_header.getCountOfDB(); i++)
		{
			IPD_DBName ipd_DbName = new IPD_DBName();
			ipd_DbName.setPosition(i + 1);
			
			// read DB Name length
			byte[] dbNameLenBytes = new byte[2];
			fin.read(dbNameLenBytes);
			System.out.println("dbNameLenBytes[0]="+ dbNameLenBytes[0] +" dbNameLenBytes[1]="+ dbNameLenBytes[1]);
			int dbNameLen = (int)(0xFF & dbNameLenBytes[0]);
			// 2nd byte is NULL
			ipd_DbName.setNameLength(dbNameLen - 1);
			System.out.println("DB Name Length: "+ dbNameLen);
			
			// read DB Name
			if(dbNameLen > 0)
				dbNameLen = dbNameLen - 1;
			byte[] dbNameBytes = new byte[dbNameLen];
			fin.read(dbNameBytes);
			fin.skip(1); // I don't need the extra byte
			ipd_DbName.setName(new String(dbNameBytes));
			System.out.println("DB Name: "+ new String(dbNameBytes));
			
			dbNames.add(ipd_DbName);
		}
		
		/*
		 * Read DB Record
		 * TODO: Consider Record length > 128K
		 * 
		 * Reference:
		 * - http://us.blackberry.com/devjournals/resources/journals/jan_2006/ipd_file_format.jsp
		 */
		System.out.println("**** Reading DB Records ****"+ ipd_header.getCountOfDB());
		
		int rowCount = 0;
		// Parse rest of the Bytes- DB Records
		while(fin.available() > 0)
		{
			// DB ID - 2 bytes (in Little Endian)
			byte[] dbIDBytes = new byte[2];
			fin.read(dbIDBytes);
			int dbID = Utils.toInt(dbIDBytes, false);
			System.out.println("_________________________________________");
			System.out.println("DB ID: "+ dbID);
			System.out.println("DB Name: "+ dbNames.get(dbID).getName());
			
			// DB Record Length: 4 bytes  (in Little Endian)
			// Little Endian- LSB (first)
			/*
			 * Record Length = DB Ver (1 byte) +
			 * 				   DB Record Handle (2 bytes) +
			 * 				   DB Record UID (4 bytes) +
			 * 				   n * (Field Header (3 byte) + Field Data)
			 * n - Number of fields
			 */
			byte[] recordLenBytes = new byte[4];
			fin.read(recordLenBytes);
			System.out.println("Bytes Record Len: "+ recordLenBytes[0] +" "+ recordLenBytes[1]+ " "+ recordLenBytes[2] +" "+ recordLenBytes[3]);
			int recordLen = Utils.toInt(recordLenBytes, false);
			
			System.out.println("###### Record Length ###### "+ recordLen);
			if(!dbNames.get(dbID).getName().equals("SMS Messages") &&
			   !dbNames.get(dbID).getName().equals("Address Book - All")) // Address Book - All
			{
				// I don't need this DB Record
				fin.skip(recordLen);
				rowCount = 0;
				continue;
			}
			
			// It is either SMS or Contact
			IPDRecord record;
			if(dbNames.get(dbID).getName().equals("SMS Messages")){
				isSMS = true;
				isContact = false;
				record = new SMS();
			}
			else{
				isContact = true;
				isSMS = false;
				record = new Contact();
			}
				
			System.out.println("Get DB Record Details....");
			record.setDbID(dbID);
			record.setRecordLength(recordLen);
			
			rowCount++;
			
			byte dbVer = (byte)fin.read();
			record.setDbVersion(dbVer);
			System.out.println("DB Version: "+ dbVer);
			
			// I don't need DB Record Handle (2 bytes) and DB Records Unique ID (2 bytes)
			//fin.skip(6);
			
			// DB Handle
			byte[] handleBytes = new byte[2];
			fin.read(handleBytes);
			int recordHandle = Utils.toInt(handleBytes, false);
			record.setRecordHandle(recordHandle);
			System.out.println("Record Handle: "+ recordHandle);
			
			// DB UID
			byte[] uidBytes = new byte[4];
			fin.read(uidBytes);
			int uid = Utils.toInt(uidBytes, false);
			System.out.println("UID: "+ uid);
			record.setRecordUID(uid);
			
			// Read Field details
			byte[] dbFieldBytes = new byte[recordLen - 7];
			fin.read(dbFieldBytes);
			System.out.println("______________FIELD DATA INFO__________________");
			record.setFields(processRecord(dbFieldBytes));
			
			if(isContact)
			{
				// Parse Contact fields
				for(int i=0; i<record.getFields().size(); i++)
				{
					IPDField field = record.getFields().get(i);
					if(field.getType() == Contact.CONTACT_DATA_TYPE)
					{
						// Parse Contact information
						record = parseContactDetails(record, field.getData());
						break;
					}
				}
			}
			else if(isSMS)
			{
				// Read SMS specific fields
				for(int i=0; i<record.getFields().size(); i++)
				{
					IPDField field = record.getFields().get(i);
					switch(field.getType()){
					/*
					 * Field type 1 - Sent & Received Date
					 * Field type 2 - Number
					 * Field type 4 - Msg
					 * Ref: https://sites.google.com/site/ipdparse/miscellaneous/date-time-stamp-information
					 */
					case SMS.TEXT_TYPE:
					{
						// Set SMS Message
						((SMS)record).setText(new String(field.getData()));
					}
					break;
					case SMS.PHONE_TYPE:
					{
						String num = new String(field.getData());
						// Offset 4 bytes from Start and 1 byte at End
						((SMS)record).setNumber(num.substring(4, num.length()-1));
					}
					break;
					case SMS.DATE_TYPE:
					{
						/*
						 * Read Sent and Received Dates- 16 bytes
						 * Offset- 13 bytes from start.
						 * Then read next 16 bytes and ignore rest
						 * 13-20 - Sent Date
						 * 21-28 - Received Date
						 */
						// Read Sent and Received Date
						byte[] sentDateBytes = new byte[8];
						byte[] receivedBytes = new byte[8];
						System.arraycopy(field.getData(), 13, sentDateBytes, 0, 8);
						System.arraycopy(field.getData(), 13+8, receivedBytes, 0, 8);
						// Little Endian Data
						long sentTime = Utils.toLong(sentDateBytes, false);
						long recvTime = Utils.toLong(receivedBytes, false);
						((SMS)record).setSentDate(sentTime);
						((SMS)record).setReceivedDate(recvTime);
					}
					break;
				}
			 } // end of FOR
			} // end of if(SMS)
			
			
			if(dbNames.get(dbID).getName().equals("SMS Messages"))
				smsRecords.add((SMS)record);
			else if(dbNames.get(dbID).getName().equals("Address Book - All"))
				contactRecords.add((Contact)record);
		}
		
		System.out.println("########### (IPD File Parsing - Success) ################");
		
		fin.close();
		
		if(listener != null)
			listener.parseComplete(contactRecords, smsRecords);
	}
	
	/**
	 * Read IPD Header
	 * 
	 * @param bytes
	 * @return
	 */
	public IPDHeader processHeader(byte[] bytes){
		IPDHeader header = new IPDHeader();
		
		byte[] rimSig = new byte[37];
		System.arraycopy(bytes, 0, rimSig, 0, rimSig.length);
		header.setRimSignature(new String(rimSig));
		header.setLineBreak(bytes[37]);
		header.setDbVersion(bytes[38]);
		System.out.println("RIM Signature: "+ new String(rimSig));
		System.out.println("Line Break: "+ bytes[37]);
		System.out.println("DB Version: "+ bytes[38]);
		
		// Count of DBs present in this IPD file
		int countOfDB = Utils.toInt(new byte[] {bytes[39], bytes[40]}, true);
		header.setCountOfDB(countOfDB);
		System.out.println("Number of DB: "+ countOfDB);
		
		header.setDbSeperator(0xFF & bytes[41]);
		System.out.println("DB Seperator: "+ bytes[41]);
		
		return header;
	}
	
	/**
	 * Read DB fields
	 * 
	 * @param bytes
	 * @return
	 * @throws Exception
	 */
	public ArrayList<IPDField> processRecord(byte[] bytes) throws Exception 
	{
		ByteArrayInputStream bin = new ByteArrayInputStream(bytes);
		ArrayList<IPDField> fields = new ArrayList<IPDField>();
		
		System.out.println("_Record Len: "+ bin.available());
		
		// traverse
		while(bin.available() > 0){
			IPDField field = new IPDField();
			// Read Field Length- 2 bytes (in Little Endian)
			byte[] fieldLenBytes = new byte[2];
			bin.read(fieldLenBytes);
			
			int fieldLen = Utils.toInt(fieldLenBytes, false);
			field.setLength(fieldLen);
			System.out.println("_Field Length: "+ fieldLen);
			
			// Read Field Type
			int fieldType = bin.read();
			field.setType(fieldType);
			System.out.println("_Field Type: "+ fieldType);
			
			// Read Field Data
			byte[] fieldData = new byte[fieldLen];
			bin.read(fieldData);
			
			field.setData(fieldData);
			
			System.out.println("_Field Data: "+ new String(field.getData()));
			System.out.println("Field Data in Hex: "+ Utils.toHex(fieldData));
			System.out.println("_Remaining Bytes to read: "+ bin.available());
			fields.add(field);
		}
		
		// Be a good boy and Close the stream :-)
		bin.close();
		
		return fields;
	}
	
	/**
	 * Parse Contact information (Data IPD Field (Type=10))
	 * e.g.
	 * 0x07 (Field Length) 0x00 0x20 (Field Type) 
	 * 0x41 0x73 0x68 0x69 0x73 0x68 0x00 (Data- Ashish)
	 * 
	 * @param record
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public IPDRecord parseContactDetails(IPDRecord record, byte[] data) throws Exception 
	{
		System.out.println("Parse Contact Details....");
		ByteArrayInputStream bin = new ByteArrayInputStream(data);
		Contact contact = (Contact)record;
		Address address = null;
		int addressType = 0;
		
		while(bin.available() > 0)
		{
			byte fieldLen = (byte)bin.read();
			// Skip 0x00
			bin.skip(1);
			
			// Field Type
			byte fieldType = (byte)bin.read();
			byte[] fieldData = new byte[fieldLen-1];
			bin.read(fieldData);
			
			// Skip 0x00
			bin.skip(1);
			
			// Find out Address type
			addressType = Contact.WORK_ADDRESS;
			if(fieldType == ContactFields.HOME_ADDRESS_FIELD ||
			   fieldType == ContactFields.HOME_ADDRESS2_FIELD	||
		       fieldType == ContactFields.HOME_CITY_FIELD ||
			   fieldType == ContactFields.HOME_STATE_FIELD ||
			   fieldType == ContactFields.HOME_PIN_FIELD ||
			   fieldType == ContactFields.HOME_COUNTRY_FIELD)
				addressType = Contact.HOME_ADDRESS;
			
			// Get the previous instance
			address = contact.getAddress().get(addressType);
			if(address == null)
				address = new Address();
			
			// Extract different field information
			switch(fieldType)
			{
				case ContactFields.NAME_FIELD:
				{
					if(contact.getFirstName() == null)
						contact.setFirstName(new String(fieldData));
					else if(contact.getLastName() == null)
						contact.setLastName(new String(fieldData));
				}
				break;
				case ContactFields.COMPANY_NAME_FIELD:
				{
					contact.setCompany(new String(fieldData));
				}
				break;
				case ContactFields.DESIGNATION_FIELD:
				{
					contact.setDesignation(new String(fieldData));
				}
				break;
				case ContactFields.EMAIL_FIELD:
				{
					contact.addEmail(new String(fieldData));
				}
				break;
				case ContactFields.WORK1_PHONE_FIELD:
				case ContactFields.WORK2_PHONE_FIELD:
				case ContactFields.HOME1_PHONE_FIELD:
				case ContactFields.HOME2_PHONE_FIELD:	
				case ContactFields.MOBILE1_FIELD:
				case ContactFields.MOBILE2_FIELD:
				case ContactFields.PAGER_FIELD:
				case ContactFields.FAX1_FIELD:
				case ContactFields.FAX2_FIELD:
				case ContactFields.OTHER_FIELD:
				case ContactFields.PIN_FIELD:
				{
					contact.addPhoneNumber(fieldType, new String(fieldData));
				}
				break;
				case ContactFields.WORK_ADDRESS_FIELD:
				case ContactFields.HOME_ADDRESS_FIELD:
				{
					address.setAddress(new String(fieldData));
					contact.addAddress(addressType, address);
				}
				break;
				case ContactFields.WORK_ADDRESS2_FIELD:
				case ContactFields.HOME_ADDRESS2_FIELD:
				{
					address.setAddress2(new String(fieldData));
					contact.addAddress(addressType, address);
				}
				break;
				case ContactFields.WORK_CITY_FIELD:
				case ContactFields.HOME_CITY_FIELD:
				{
					address.setAddress2(new String(fieldData));
					contact.addAddress(addressType, address);
				}
				break;
				case ContactFields.WORK_STATE_FIELD:
				case ContactFields.HOME_STATE_FIELD:
				{
					address.setState(new String(fieldData));
					contact.addAddress(addressType, address);
				}
				break;
				case ContactFields.WORK_PIN_FIELD:
				case ContactFields.HOME_PIN_FIELD:
				{
					address.setPin(new String(fieldData));
					contact.addAddress(addressType, address);
				}
				break;
				case ContactFields.WORK_COUNTRY_FIELD:
				case ContactFields.HOME_COUNTRY_FIELD:
				{
					address.setCountry(new String(fieldData));
					contact.addAddress(addressType, address);
				}
				break;
				case ContactFields.BIRTHDAY_FIELD:
				{
					// BD: 15/8/1947
					// TODO: Convert to TimeStamp
					contact.setBirthday(new String(fieldData));
				}
				break;
				case ContactFields.ANNIVERSARY_FIELD:
				{
					// BD: 15/8/1947
					// TODO: Convert to TimeStamp
					contact.setAnniversary(new String(fieldData));
				}
				break;
				case ContactFields.WEBPAGE_FIELD:
				{
					contact.setWebPage(new String(fieldData));
				}
				break;
				case ContactFields.NOTE_FIELD:
				{
					contact.setNote(new String(fieldData));
				}
				break;
				}
		}
		
		// Be a good boy and Close the stream :-)
		bin.close();
		
		return contact;
	}
	
	// Call back interface for User program
	public interface Callback
	{
		public void parseComplete(ArrayList<Contact> contacts, ArrayList<SMS> sms);
	}
}

